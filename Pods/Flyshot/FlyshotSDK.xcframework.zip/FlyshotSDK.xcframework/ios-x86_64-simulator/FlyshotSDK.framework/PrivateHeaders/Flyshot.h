//
//  Flyshot.h
//  Flyshot
//
//  Created by Artsiom Likhatch on 5/29/19.
//  Copyright © 2019 FlyshotInc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Flyshot.
FOUNDATION_EXPORT double FlyshotVersionNumber;

//! Project version string for Flyshot.
FOUNDATION_EXPORT const unsigned char FlyshotVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Flyshot/PublicHeader.h>
