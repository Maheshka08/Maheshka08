//
//  Flyshot-Bridging-Header.h
//  Flyshot
//
//  Created by Artyom Lihach on 26/06/2019.
//  Copyright © 2019 FlyshotInc. All rights reserved.
//

#ifndef Flyshot_Bridging_Header_h
#define Flyshot_Bridging_Header_h


#endif /* Flyshot_Bridging_Header_h */
